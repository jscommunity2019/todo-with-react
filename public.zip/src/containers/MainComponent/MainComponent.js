import React, { Component } from 'react';
import './MainComponent.css';
import ListButton from '../../components/ListButtons';

class MainComponent extends Component {


  state = {
    expression : ''
  };

  changeHandler = (event) => {

    if(this.helperfunction(event.target.value)){
      if(this.state.expression.length === 0){
        this.setState({
          expression : this.state.expression
        });
      }
      else if(this.helperfunction(this.state.expression[this.state.expression.length-1])){
        this.setState({
          expression : this.state.expression
        });
      }
      else{
        this.setState({
          expression : this.state.expression + event.target.value
        });
      }
    }

    else if(event.target.value === 'clear'){
      this.setState({
        expression : ''
      });
    }

    else if(event.target.value === '='){
      this.setState({
        expression : eval(this.state.expression)
      });
    }

    else{
      this.setState({
        expression : this.state.expression + event.target.value
      });
    }

  };

  helperfunction = (char) => {
    return "+-/*".indexOf(char) !== -1;
  };


  render(){


  return (
      <div className="container Main">
        <div className="row justify-content-center align-items-center">
          <div className="col-md-4"></div>
          <div className="col-md-4">
            <div className="row justify-content-center">
              <h1>Calculator</h1>
            </div>
            <div className="row">
              <input type="text" className="form-control" readOnly value={this.state.expression}/>
            </div>
            <br/>
            <ListButton value={['1','2','3','+']} click={this.changeHandler}/>
            <br/>
            <ListButton value={['4','5','6','-']} click={this.changeHandler}/>
            <br/>
            <ListButton value={['7','8','9','*']} click={this.changeHandler}/>
            <br/>
            <ListButton value={['0','/','clear','=']} click={this.changeHandler}/>
            <br/>
          </div>
          <div className="col-md-4"></div>
        </div>
      </div>
    );
  }
}
 
export default MainComponent;