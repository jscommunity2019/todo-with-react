import React from 'react';
import './ListButton.css';

const listButton = (props) => {

    let data = props.value.map((element,index) => {
        return (
            <div className="col-md-3" key={index}>
                <button className="btn btn-primary" value={element} onClick={props.click}>{element}</button>
            </div>
        );
    });
    
    return (
        <div className="row list">
            {data}
        </div>
    );
};


export default listButton;