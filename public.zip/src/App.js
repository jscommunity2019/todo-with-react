import React from 'react';
import './App.css';
import MainComponent from './containers/MainComponent/MainComponent';

function App() {
  return (
    <div className="App">
      <MainComponent />
    </div>
  );
}

export default App;
